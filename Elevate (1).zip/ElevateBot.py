import discord
from discord.ext import commands, tasks
import pymysql.cursors
from datetime import datetime, timedelta
from dateutil.parser import parse as parse_datetime
import random
import string
import asyncio
import secrets
import os
import shutil
import json
import enum
import requests
import subprocess
import pytz
from discord.ui import Select, View

intents = discord.Intents.all()
client = discord.Client(intents=intents)
tree = discord.app_commands.CommandTree(client)

class BuildType(enum.Enum):
    Live = "Live"
    Beta = "Beta"
    Debug = "Debug"

# Function to establish MySQL connection
def get_connection():
    return pymysql.connect(host='localhost',
                             user='root',
                             password='pass',
                             db='user_data',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

@client.event
async def on_ready():
    await tree.sync()  # Sync the commands with Discord
    activity = discord.Game(name="watching you 👀", type=3)
    await client.change_presence(status=discord.Status.online, activity=activity)

# Function to create project folder and files
def create_lua_project(lua_name):
    project_path = f'/root/projects/lua/lua/{lua_name}'
    os.makedirs(project_path, exist_ok=True)
    
    for file_type in ['live', 'beta', 'debug']:
        with open(os.path.join(project_path, f'{file_type}.lua'), 'w') as f:
            f.write('')

    return project_path

# Command to register the lua project
@tree.command(name="register", description="Register a new lua project")
async def register(interaction: discord.Interaction, lua_name: str, key: str):
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages:
        try:
            guild_id = str(interaction.guild.id)
            
            # Check if the key exists and is not already used
            connection = get_connection()
            with connection.cursor() as cursor:
                cursor.execute('SELECT * FROM lua_projects WHERE `key` = %s', (key,))
                project_data = cursor.fetchone()
                
                if project_data:
                    if project_data['key_used'] == 0:
                        # Key exists and is available, update key_used to 1 and project_path
                        project_path = create_lua_project(lua_name)
                        cursor.execute('''
                        UPDATE lua_projects 
                        SET key_used = 1, guild_id = %s, lua_name = %s, project_path = %s
                        WHERE `key` = %s
                        ''', (guild_id, lua_name, project_path, key))
                        connection.commit()
                        
                        await interaction.response.send_message(f"Your'{lua_name}' lua registered successfully.", ephemeral=True)
                    else:
                        await interaction.response.send_message(f"The provided key is already used.", ephemeral=True)
                else:
                    await interaction.response.send_message(f"The provided key is invalid.", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred: {str(e)}")
        finally:
            connection.close()
    else:
        await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)


def calculate_remaining_time(subscription_time):
    try:
        subscription_datetime = datetime.strptime(subscription_time, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=pytz.UTC)
        current_datetime = datetime.utcnow().replace(tzinfo=pytz.UTC)
        remaining_time = subscription_datetime - current_datetime

        # Calculate days, hours, minutes, seconds
        days = remaining_time.days
        hours, remainder = divmod(remaining_time.seconds, 3600)
        minutes, seconds = divmod(remainder, 60)

        return f"{days} days, {hours} hours, {minutes} minutes, {seconds} seconds"
    except ValueError:
        return "Invalid timestamp"

@tree.command(name="profile", description="Get user profile information")
async def profile_command(interaction: discord.Interaction, user: str):
    # Check if the user invoking the command has sufficient permissions
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages:
        try:
            connection = get_connection()  # Establish a new database connection
            with connection.cursor() as cursor:
                # Initialize variables to store query results
                user_data = None
                discord_id = None

                # Check if the input is a mention (Discord ID)
                if user.startswith('<@') and user.endswith('>'):
                    # Extracting the Discord ID from the mention
                    discord_id = user.strip('<@!>')
                    # Find the user in the database by Discord ID
                    sql = "SELECT * FROM user_data.users WHERE discord_id = %s"
                    cursor.execute(sql, (discord_id,))
                else:
                    # Find the user in the database by username (case insensitive search)
                    sql = "SELECT * FROM user_data.users WHERE LOWER(username) = LOWER(%s)"
                    cursor.execute(sql, (user,))
                
                user_data = cursor.fetchone()

                if user_data:
                    username = user_data['username']
                    discord_id = user_data['discord_id']
                    lua_data = json.loads(user_data['lua_data']) if user_data['lua_data'] else []

                    embed = discord.Embed(title=f"User Profile for {username}", color=0x00ff00)
                    embed.add_field(name="Username", value=username, inline=False)
                    embed.add_field(name="Discord ID", value=f"<@{discord_id}>", inline=False)

                    # Iterate through Lua projects associated with the user
                    for idx, project in enumerate(lua_data, start=1):
                        lua_name = project.get('name', 'Not specified')
                        build = project.get('build', 'Not specified')
                        time = project.get('time', 'Not specified')
                        ban_status = "True" if project.get('ban', False) else "False"

                        try:
                            remaining_time_str = calculate_remaining_time(time)
                        except ValueError:
                            remaining_time_str = "Invalid timestamp"

                        embed.add_field(name=f"Lua {idx}: {lua_name.capitalize()}",
                                        value=f"Build: {build}\nTime: {remaining_time_str}\nBanned: {ban_status}",
                                        inline=False)

                    await interaction.response.send_message(embed=embed, ephemeral=True)
                else:
                    await interaction.response.send_message("User not found.", ephemeral=True)
            
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the database connection after execution
    else:
        await interaction.response.send_message("You do not have sufficient permissions to perform this action.", ephemeral=True)
        
@tree.command(name="license", description="license key")
async def license(interaction: discord.Interaction):
    # Replace 'YOUR_DISCORD_USER_ID' with the actual user ID allowed to use this command
    allowed_user_id = '886239464756768808'

    if str(interaction.user.id) == allowed_user_id:
        try:
            connection = get_connection()
            new_key = None
            key_exists = True
            
            while key_exists:
                new_key = secrets.token_hex(16)  # Generate a random 16-byte hex key
                with connection.cursor() as cursor:
                    cursor.execute('SELECT * FROM lua_projects WHERE `key` = %s', (new_key,))
                    key_data = cursor.fetchone()
                    if not key_data:
                        key_exists = False
            
            # Insert the new key into the database with key_used set to 0
            with connection.cursor() as cursor:
                cursor.execute('''
                INSERT INTO lua_projects (guild_id, lua_name, project_path, `key`, key_used)
                VALUES (%s, %s, %s, %s, %s)
                ''', ('', '', '', new_key, 0))
                connection.commit()
            
            await interaction.response.send_message(f"Generated new license: {new_key}", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message(f"An error occurred: {str(e)}")
        finally:
            connection.close()
    else:
        await interaction.response.send_message("You do not have permission to use this command.", ephemeral=True)

@tree.command(name="update", description="Upload a build file attachment")
async def upload_build(interaction: discord.Interaction, build: BuildType, file: discord.Attachment):
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages:
        try:
            # Fetch Lua project name based on guild
            connection = get_connection()  # Establish a new connection
            with connection.cursor() as cursor:
                sql_select_lua_name = "SELECT lua_name FROM user_data.lua_projects WHERE guild_id = %s"
                cursor.execute(sql_select_lua_name, (interaction.guild.id,))
                project_data = cursor.fetchone()

                if project_data:
                    lua_name = project_data['lua_name']
                else:
                    await interaction.response.send_message("No Lua project found for this guild. Please set up a Lua project first.", ephemeral=True)
                    return

            # Define base directory path
            base_directory = "/root/projects/lua/lua"

            # Construct file paths based on build type and Lua project name
            if build == BuildType.Live:
                file_path = f"{base_directory}/{lua_name}/live.lua"
            elif build == BuildType.Beta:
                file_path = f"{base_directory}/{lua_name}/beta.lua"
            elif build == BuildType.Debug:
                file_path = f"{base_directory}/{lua_name}/debug.lua"
            else:
                await interaction.response.send_message("Invalid build type!", ephemeral=True)
                return

            # Save the attached file with the appropriate name
            await file.save(file_path)

            # Send a message indicating the build name updated and who executed the command
            await interaction.response.send_message(f"**{build.value} build** updated <@{interaction.user.id}>", ephemeral=True)
        except FileNotFoundError as e:
            print(f"Error: {e}")
            await interaction.response.send_message(f"Error: {e}. Please check the file path and ensure directories exist.", ephemeral=True)
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the connection after execution
    else:
        await interaction.response.send_message("You are not an admin! :detective:", ephemeral=True)


def generate_key(luaname, length=40):
    characters = string.ascii_letters + string.digits
    random_chars = ''.join(secrets.choice(characters) for _ in range(length))
    return f"{luaname}{{{random_chars}}}"

def generate_beta_key(luaname, length=40):
    characters = string.ascii_letters + string.digits
    random_chars = ''.join(secrets.choice(characters) for _ in range(length))
    return f"{luaname}beta{{{random_chars}}}"

def generate_debug_key(luaname, length=40):
    characters = string.ascii_letters + string.digits
    random_chars = ''.join(secrets.choice(characters) for _ in range(length))
    return f"{luaname}debug{{{random_chars}}}"



@tree.command(name="generate_keys", description="Generate a key")
async def key_command(
    interaction: discord.Interaction,
    days: int,
    build: BuildType
):
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages:
        try:
            connection = get_connection()  # Establish a new connection
            with connection.cursor() as cursor:
                # Fetch Lua project information for the guild
                guild_id = interaction.guild.id
                sql_project = "SELECT lua_name FROM user_data.lua_projects WHERE guild_id = %s"
                cursor.execute(sql_project, (guild_id,))
                project_data = cursor.fetchone()

                if not project_data:
                    await interaction.response.send_message("No Lua project found for this guild.", ephemeral=True)
                    return

                lua_name = project_data['lua_name']

                # Ensure that the build is either "regular", "beta", or "debug"
                valid_builds = [BuildType.Live, BuildType.Beta, BuildType.Debug]
                if build not in valid_builds:
                    await interaction.response.send_message("Invalid build type! Please specify either 'live', 'beta', or 'debug'.", ephemeral=True)
                    return

                # Generate the key based on the specified build type and Lua project
                if build == BuildType.Beta:
                    # Generate a beta key
                    generated_key = generate_beta_key(lua_name)
                elif build == BuildType.Debug:
                    # Generate a debug key
                    generated_key = generate_debug_key(lua_name)
                else:
                    # Generate a regular key
                    generated_key = generate_key(lua_name)

                # Calculate expiry time
                expiry_time = (datetime.now() + timedelta(days=days)).strftime('%Y-%m-%d %H:%M:%S')

                # Update the SQL query to insert the generated key into user_data.keys
                sql = "INSERT INTO user_data.keys (key_value, expiry_time) VALUES (%s, %s)"
                cursor.execute(sql, (generated_key, expiry_time))
                connection.commit()

                # Send the key to the user without ephemeral set to True
                await interaction.response.send_message(f"Successfully generated {days} days key for {build.value}\n```{generated_key}```")
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the connection after execution
    else:
        await interaction.response.send_message("You are not admin! :detective:", ephemeral=True)

# @tree.command(name="link", description="Link a Discord user to their username")
# async def link_command(interaction: discord.Interaction, username: str):
#     try:
#         connection = get_connection()  # Establish a new connection
#         with connection.cursor() as cursor:
#             # Check if the discord_id column exists in the users table
#             # cursor.execute("SHOW COLUMNS FROM users LIKE 'discord_id'")
#             # if not cursor.fetchone():
#             #     # discord_id column doesn't exist, so we need to add it
#             #     cursor.execute("ALTER TABLE users ADD COLUMN discord_id TEXT")
#             #     connection.commit()
#             #     await interaction.response.send_message("discord_id column added to the users table. Please rerun the command.", ephemeral=True)
#             #     return
#             
#             # Check if the user exists in the database
#             # sql_select_user = "SELECT * FROM users WHERE username = %s"
#             # cursor.execute(sql_select_user, (username,))
#             # existing_user = cursor.fetchone()
#             
#             # if existing_user:
#             #     # Check if the user already has a discord_id linked
#             #     if existing_user["discord_id"]:
#             #         if existing_user["discord_id"] == str(interaction.user.id):
#             #             await interaction.response.send_message(f"You are already linked to the username: {username}.", ephemeral=True)
#             #         else:
#             #             await interaction.response.send_message("This username is already linked to another Discord user. If you want to reset, please contact xlumiel on Discord.", ephemeral=True)
#             #     else:
#             #         # Link the Discord user ID to the provided username
#             #         sql_update = "UPDATE users SET discord_id = %s WHERE username = %s"
#             #         cursor.execute(sql_update, (str(interaction.user.id), username))
#             #         connection.commit()
#             #         # Log the command
#             #         await interaction.response.send_message(f"You've been successfully linked to the username: {username}", ephemeral=True)
#             #         await sync_roles(interaction)  # Trigger sync after linking
#             # else:
#             #     await interaction.response.send_message(f"The provided username does not exist.", ephemeral=True)
#     except Exception as e:
#         print(f"Error: {e}")
#         await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
#     finally:
#         connection.close()  # Close the connection after execution

@tree.command(name="subscription", description="Give subscription to a user or all users")
async def subscription_command(
    interaction: discord.Interaction,
    user: str,
    days: int
):
    if interaction.user.guild_permissions.administrator:
        try:
            connection = get_connection()  # Establish a new connection
            with connection.cursor() as cursor:
                # Fetch Lua project information for the guild
                guild_id = interaction.guild.id
                sql_project = "SELECT lua_name FROM user_data.lua_projects WHERE guild_id = %s"
                cursor.execute(sql_project, (guild_id,))
                project_data = cursor.fetchone()

                if project_data:
                    lua_name = project_data['lua_name']

                    if user.lower() == "all":
                        # Give days to all users in the Lua project
                        sql_select = "SELECT username, lua_data FROM user_data.users"
                        cursor.execute(sql_select)
                        user_data = cursor.fetchall()

                        # Iterate through each user's data
                        for user_info in user_data:
                            # Parse LuaData as JSON
                            lua_data = json.loads(user_info['lua_data'])
                            updated_lua_data = []

                            # Iterate through each entry in lua_data
                            for entry in lua_data:
                                if 'name' in entry and entry['name'].lower() == lua_name.lower():
                                    # Update the 'time' field for the matching entry
                                    current_time = datetime.fromisoformat(entry['time'].replace('Z', '+00:00'))  # Convert to datetime object
                                    new_time = current_time + timedelta(days=days)
                                    entry['time'] = new_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')

                                updated_lua_data.append(entry)

                            # Update the database with the modified lua_data
                            sql_update = "UPDATE user_data.users SET lua_data = %s WHERE username = %s"
                            cursor.execute(sql_update, (json.dumps(updated_lua_data), user_info['username']))

                        connection.commit()
                        await interaction.response.send_message(f"All users with Lua name '{lua_name}' have been given {days} days.", ephemeral=True)
                    else:
                        # Give days to a specific user in the Lua project
                        sql_select = "SELECT lua_data FROM user_data.users WHERE username = %s"
                        cursor.execute(sql_select, (user,))
                        user_data = cursor.fetchone()

                        if user_data:
                            lua_data = json.loads(user_data['lua_data'])
                            updated_lua_data = []

                            # Iterate through each entry in lua_data
                            for entry in lua_data:
                                if 'name' in entry and entry['name'].lower() == lua_name.lower():
                                    current_time = datetime.fromisoformat(entry['time'].replace('Z', '+00:00'))  # Convert to datetime object
                                    new_time = current_time + timedelta(days=days)
                                    entry['time'] = new_time.strftime('%Y-%m-%dT%H:%M:%S.000Z')

                                updated_lua_data.append(entry)

                            # Update the database with the modified lua_data
                            sql_update = "UPDATE user_data.users SET lua_data = %s WHERE username = %s"
                            cursor.execute(sql_update, (json.dumps(updated_lua_data), user))
                            connection.commit()
                            await interaction.response.send_message(f"{days} days given to user '{user}' with Lua name '{lua_name}'.", ephemeral=True)
                        else:
                            await interaction.response.send_message(f"User '{user}' not found or does not have LuaData.", ephemeral=True)
                else:
                    await interaction.response.send_message("No Lua project found for this guild.", ephemeral=True)
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the connection after execution
    else:
        await interaction.response.send_message("You are not an administrator! :detective:", ephemeral=True)

# Command decorator with interaction support
@tree.command(name="upgrade", description="Upgrade or downgrade a user's build type")
async def upgrade_command(
    interaction: discord.Interaction,
    username: str,
    build: BuildType  # Build type input using the BuildType enum
):
    # Check if the user has sufficient permissions
    if interaction.user.guild_permissions.administrator or interaction.user.guild_permissions.manage_messages:
        try:
            connection = get_connection()  # Establish a new connection (your method to get connection)
            with connection.cursor() as cursor:
                # Fetch Lua project information for the guild
                guild_id = interaction.guild.id
                sql_project = "SELECT lua_name FROM user_data.lua_projects WHERE guild_id = %s"
                cursor.execute(sql_project, (guild_id,))
                project_data = cursor.fetchone()

                if not project_data:
                    await interaction.response.send_message("No Lua project found for this guild.", ephemeral=True)
                    return

                lua_name = project_data['lua_name']

                # Retrieve the user's Lua data from the database
                sql_select = "SELECT lua_data FROM user_data.users WHERE username = %s"
                cursor.execute(sql_select, (username,))
                user_data = cursor.fetchone()

                if not user_data:
                    await interaction.response.send_message(f"User '{username}' not found or does not have LuaData.", ephemeral=True)
                    return

                # Parse the LuaData JSON
                lua_data = json.loads(user_data['lua_data'])
                updated_lua_data = []

                # Update the build type for the user in LuaData
                for entry in lua_data:
                    if 'name' in entry and entry['name'].lower() == lua_name.lower():
                        entry['build'] = build.value

                # Update the database with the modified LuaData
                sql_update = "UPDATE user_data.users SET lua_data = %s WHERE username = %s"
                cursor.execute(sql_update, (json.dumps(lua_data), username))
                connection.commit()

                await interaction.response.send_message(f"Successfully upgraded user '{username}' to '{build.value}' build.", ephemeral=True)

        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the database connection

    else:
        await interaction.response.send_message("You do not have sufficient permissions to perform this action.", ephemeral=True)
        

# Command decorator with interaction support
@tree.command(name="ban", description="Ban a user")
async def ban_command(interaction: discord.Interaction, user: str):
    # Check if the user invoking the command has administrator permissions
    if interaction.user.guild_permissions.administrator:
        try:
            connection = get_connection()  # Establish a new database connection (your method to get connection)
            with connection.cursor() as cursor:
                # Fetch Lua project information for the guild
                guild_id = interaction.guild.id
                sql_project = "SELECT lua_name FROM user_data.lua_projects WHERE guild_id = %s"
                cursor.execute(sql_project, (guild_id,))
                project_data = cursor.fetchone()

                if not project_data:
                    await interaction.response.send_message("No Lua project found for this guild.", ephemeral=True)
                    return

                lua_name = project_data['lua_name']

                # Check if the input is a mention (Discord ID)
                if user.startswith('<@') and user.endswith('>'):
                    # Extracting the Discord ID from the mention
                    discord_id = user.strip('<@!>')
                    # Find the user in the Lua project database by Discord ID
                    sql = "SELECT lua_data FROM user_data.users WHERE discord_id = %s"
                    cursor.execute(sql, (discord_id,))
                else:
                    # Find the user in the Lua project database by username
                    sql = "SELECT lua_data FROM user_data.users WHERE Username = %s"
                    cursor.execute(sql, (user,))
                
                user_data = cursor.fetchone()

                if user_data:
                    lua_data = json.loads(user_data['lua_data'])
                    updated_lua_data = []

                    # Check if the user is already banned
                    already_banned = False
                    for entry in lua_data:
                        if 'name' in entry and entry['name'].lower() == lua_name.lower():
                            if entry.get('ban', False):
                                already_banned = True
                                break

                    if already_banned:
                        await interaction.response.send_message(f"{user} is already banned.", ephemeral=True)
                    else:
                        # Update the ban status in the LuaData JSON
                        for entry in lua_data:
                            if 'name' in entry and entry['name'].lower() == lua_name.lower():
                                entry['ban'] = True  # Set the 'ban' field to True

                        # Update the database with the modified LuaData
                        if user.startswith('<@'):
                            sql_update = "UPDATE user_data.users SET lua_data = %s WHERE discord_id = %s"
                            cursor.execute(sql_update, (json.dumps(lua_data), discord_id))
                        else:
                            sql_update = "UPDATE user_data.users SET lua_data = %s WHERE Username = %s"
                            cursor.execute(sql_update, (json.dumps(lua_data), user))
                        connection.commit()

                        await interaction.response.send_message(f"{user} has been banned.", ephemeral=True)
                else:
                    await interaction.response.send_message("User not found.", ephemeral=True)
            
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the database connection
    else:
        await interaction.response.send_message("You are not an administrator! :detective:")

@tree.command(name="unban", description="Unban a user")
async def unban_command(interaction: discord.Interaction, user: str):
    # Check if the user invoking the command has administrator permissions
    if interaction.user.guild_permissions.administrator:
        try:
            connection = get_connection()  # Establish a new database connection (your method to get connection)
            with connection.cursor() as cursor:
                # Fetch Lua project information for the guild
                guild_id = interaction.guild.id
                sql_project = "SELECT lua_name FROM user_data.lua_projects WHERE guild_id = %s"
                cursor.execute(sql_project, (guild_id,))
                project_data = cursor.fetchone()

                if not project_data:
                    await interaction.response.send_message("No Lua project found for this guild.", ephemeral=True)
                    return

                lua_name = project_data['lua_name']

                # Check if the input is a mention (Discord ID)
                if user.startswith('<@') and user.endswith('>'):
                    # Extracting the Discord ID from the mention
                    discord_id = user.strip('<@!>')
                    # Find the user in the Lua project database by Discord ID
                    sql = "SELECT lua_data FROM user_data.users WHERE discord_id = %s"
                    cursor.execute(sql, (discord_id,))
                else:
                    # Find the user in the Lua project database by username
                    sql = "SELECT lua_data FROM user_data.users WHERE Username = %s"
                    cursor.execute(sql, (user,))
                
                user_data = cursor.fetchone()

                if user_data:
                    lua_data = json.loads(user_data['lua_data'])
                    updated_lua_data = []

                    # Check if the user is already unbanned
                    already_unbanned = True
                    for entry in lua_data:
                        if 'name' in entry and entry['name'].lower() == lua_name.lower():
                            if entry.get('ban', True):
                                already_unbanned = False
                                break

                    if already_unbanned:
                        await interaction.response.send_message(f"{user} is not banned.", ephemeral=True)
                    else:
                        # Update the ban status in the LuaData JSON
                        for entry in lua_data:
                            if 'name' in entry and entry['name'].lower() == lua_name.lower():
                                entry['ban'] = False  # Set the 'ban' field to False

                        # Update the database with the modified LuaData
                        if user.startswith('<@'):
                            sql_update = "UPDATE user_data.users SET lua_data = %s WHERE discord_id = %s"
                            cursor.execute(sql_update, (json.dumps(lua_data), discord_id))
                        else:
                            sql_update = "UPDATE user_data.users SET lua_data = %s WHERE Username = %s"
                            cursor.execute(sql_update, (json.dumps(lua_data), user))
                        connection.commit()

                        await interaction.response.send_message(f"{user} has been unbanned.", ephemeral=True)
                else:
                    await interaction.response.send_message("User not found.", ephemeral=True)
            
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the database connection
    else:
        await interaction.response.send_message("You are not an administrator! :detective:")


# Command decorator with interaction support
@tree.command(name="hwid", description="Reset HWID for a user")
async def reset_command(interaction: discord.Interaction, user: str):
    # Check if the user invoking the command has administrator permissions
    if interaction.user.guild_permissions.administrator:
        try:
            connection = get_connection()  # Establish a new database connection (your method to get connection)
            with connection.cursor() as cursor:
                # Check if the input is a mention (Discord ID)
                if user.startswith('<@') and user.endswith('>'):
                    # Extracting the Discord ID from the mention
                    discord_id = user.strip('<@!>')
                    # Find the user in the database by Discord ID
                    sql = "SELECT * FROM users WHERE discord_id = %s"
                    cursor.execute(sql, (discord_id,))
                    user_data = cursor.fetchone()
                else:
                    # Find the user in the database by username
                    sql = "SELECT * FROM users WHERE Username = %s"
                    cursor.execute(sql, (user,))
                    user_data = cursor.fetchone()
                
                if user_data:
                    # Reset HWID for the user
                    if user.startswith('<@') and user.endswith('>'):
                        # If the input is a mention (Discord ID), update HWID by Discord ID
                        sql_update = "UPDATE users SET hwid = NULL WHERE discord_id = %s"
                        cursor.execute(sql_update, (discord_id,))
                    else:
                        # If the input is a username, update HWID by username
                        sql_update = "UPDATE users SET hwid = NULL WHERE Username = %s"
                        cursor.execute(sql_update, (user,))
                    
                    connection.commit()

                    # Log the command
                    await interaction.response.send_message(f"HWID reset for {user}.", ephemeral=True)

                    # Fetch the user from Discord (optional)
                    user_object = await client.fetch_user(int(discord_id))

                    # Example: Send a DM to the user with embed
                    embed = discord.Embed(title="HWID Reset", description=f"Your HWID has been reset by <@{interaction.user.id}>.", color=0x00ff00)
                    await user_object.send(embed=embed)
                else:
                    await interaction.response.send_message("User not found.", ephemeral=True)
            
        except Exception as e:
            print(f"Error: {e}")
            await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)
        finally:
            connection.close()  # Close the database connection
    else:
        await interaction.response.send_message("You are not an admin! :detective:", ephemeral=True)

# Define the folder path where loader.lua is located
LOADER_FOLDER_PATH = "/root/projects/lua"

@tree.command(name="loader", description="Download the loader")
async def download_loader_command(interaction: discord.Interaction):
    try:
        # Check if loader.lua exists in the specified folder
        loader_path = os.path.join(LOADER_FOLDER_PATH, "loader.lua")
        if not os.path.exists(loader_path):
            await interaction.response.send_message("loader file not found", ephemeral=True)
            return
        
        # Send the loader.lua file as an attachment
        with open(loader_path, "rb") as file:
            await interaction.response.send_message("**Loader Download**", ephemeral=True, file=discord.File(file, "loader.lua"))
    
    except Exception as e:
        print(f"Error: {e}")
        await interaction.response.send_message("An error occurred while performing the action.", ephemeral=True)

# Run the bot with your token
client.run('token')
