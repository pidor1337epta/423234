const express = require('express');
const mysql = require('mysql');
const fs = require('fs');
const path = require('path');
const app = express();
const moment = require('moment'); // for date/time formatting
const port = 1440;

// MySQL database connections
const userDataConnection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'pass',
    database: 'user_data' // Connect to 'user_data' database
});

// Connect to user_data database
userDataConnection.connect(err => {
    if (err) {
        console.error('Error connecting to the user_data database:', err);
        return;
    }
    console.log('Connected to the user_data database');
});

app.use(express.json());

// Function to check if a Lua script is valid based on current time
function isLuaScriptValid(luaScript) {
    const currentTime = new Date();
    const expiryTime = new Date(luaScript.time);

    console.log(`Current Time: ${currentTime}, Expiry Time: ${expiryTime}`);

    return !luaScript.ban && currentTime < expiryTime;
}

// Function to encode file content as base64
function encodeBase64(filePath) {
    try {
        const fileContent = fs.readFileSync(filePath, 'utf8');
        return Buffer.from(fileContent).toString('base64');
    } catch (error) {
        console.error('Error encoding file as base64:', error);
        return null;
    }
}

app.post('/api/load/:username/:hwid/:lua?', (req, res) => {
    const { username, hwid, lua } = req.params;
    const { discordid } = req.query; // Optional query parameter for Discord ID

    // Convert lua parameter to lowercase
    const luaNameLowerCase = lua ? lua.toLowerCase() : null;

    // Fetch user data from users table based on username
    userDataConnection.query('SELECT id, username, hwid, lua_data, loader_ban, discord_id FROM users WHERE username = ?', [username], (err, userResults) => {
        if (err) {
            res.status(500).send('Database query failed (users): ' + err.message);
            return;
        }

        if (userResults.length > 0) {
            const userData = userResults[0];

            // Check if hwid matches
            if (userData.hwid !== hwid) {
                if (!userData.hwid) {
                    // If hwid is null, update it and respond with successful hwid reset
                    userDataConnection.query('UPDATE users SET hwid = ? WHERE username = ?', [hwid, username], (err, updateResults) => {
                        if (err) {
                            console.error('Failed to update hwid:', err);
                            res.status(500).send('Failed to update hwid');
                        } else {
                            console.log(`Updated hwid for user ${username}: ${hwid}`);
                            res.status(200).send('Successfully reset hwid');
                        }
                    });
                } else {
                    // If hwid does not match and is not null, respond with wrong hwid error
                    res.status(401).send('Wrong Hwid. Please contact support.');
                }
                return;
            }

            // Check if the user is loader banned
            if (userData.loader_ban === 1) {
                res.status(403).send('You are loader banned. If you think this is a mistake, please contact Lumiel.');
                return;
            }

            // Check if discord_id is NULL and if a new discordid is provided
            if (!userData.discord_id && discordid) {
                // Update discord_id if it's NULL
                userDataConnection.query('UPDATE users SET discord_id = ? WHERE username = ?', [discordid, username], (err, updateResults) => {
                    if (err) {
                        console.error('Failed to update discord_id:', err);
                        res.status(500).send('Failed to update discord_id');
                    } else {
                        console.log(`Updated discord_id for user ${username}: ${discordid}`);
                        res.status(200).send('Successfully updated discord_id');
                    }
                });
                return;
            }

            try {
                // Parse lua_data JSON
                const luaData = JSON.parse(userData.lua_data);

                if (lua) {
                    // Check if the requested Lua script exists and is valid (case-insensitive)
                    const luaScript = luaData.find(script => script.name.toLowerCase() === luaNameLowerCase);

                    if (luaScript && isLuaScriptValid(luaScript)) {
                        const buildType = luaScript.build || 'live'; // Default to 'live' if build type is not specified

                        // Fetch project_path from lua_projects table based on lua_name
                        const projectPathQuery = 'SELECT project_path FROM user_data.lua_projects WHERE LOWER(lua_name) = ?';
                        userDataConnection.query(projectPathQuery, [luaNameLowerCase], (err, projectResults) => {
                            if (err) {
                                res.status(500).send('Database query failed (lua_projects): ' + err.message);
                                return;
                            }

                            if (projectResults.length > 0) {
                                const projectPath = projectResults[0].project_path;

                                // Construct the Lua file path based on buildType
                                let luaFilePath = path.join(projectPath, `${buildType}.lua`);

                                // Encode Lua script content as base64
                                const base64Content = encodeBase64(luaFilePath);

                                if (base64Content) {
                                    // Send base64-encoded content as JSON response
                                    res.json({ base64_data: base64Content });
                                } else {
                                    res.status(500).send('Error loading Lua script or encoding as base64');
                                }
                            } else {
                                res.status(404).send(`Lua project path not found for lua_name: ${lua}`);
                            }
                        });
                    } else {
                        // Log why the Lua script is considered expired or banned
                        if (luaScript) {
                            const reason = luaScript.ban ? 'Banned' : 'Subscription expired';
                            console.log(`Cannot load ${lua}: ${reason}`);
                            res.status(403).send(`${reason}`);
                        } else {
                            console.log('Lua script not found');
                            res.status(404).send("Sorry, but the lua script you are trying to load doesn't exist, please do lua_scripts for list of available lua scripts");
                        }
                    }
                } else {
                    // Respond with user exists message if no lua parameter specified
                    res.status(200).send('User exists');
                }
            } catch (error) {
                console.error('Error parsing lua_data JSON:', error);
                res.status(500).send('Error parsing lua_data JSON');
            }
        } else {
            res.status(404).send('User not found');
        }
    });
});

// Function to redeem a key and extend Lua script validity
app.post('/api/redeem/:username/:hwid/:key', (req, res) => {
    const { username, hwid, key } = req.params;

    // Check if the key exists and is valid
    const keyQuery = 'SELECT * FROM `keys` WHERE `key_value` = ? AND `expiry_time` > NOW()';
    userDataConnection.query(keyQuery, [key], (err, keyResults) => {
        if (err) {
            res.status(500).send('Database query failed (keys): ' + err.message);
            return;
        }

        if (keyResults.length > 0) {
            // Extract lua name and determine build type from key
            const { luaName, buildType } = extractLuaNameAndBuildType(key); // Function to extract lua name and build type

            if (!luaName) {
                res.status(403).send('Invalid Lua project');
                return;
            }

            // Key is valid, fetch user data
            userDataConnection.query('SELECT id, username, hwid, lua_data, loader_ban FROM users WHERE username = ? AND hwid = ?', [username, hwid], (err, userResults) => {
                if (err) {
                    res.status(500).send('Database query failed (users): ' + err.message);
                    return;
                }

                if (userResults.length > 0) {
                    const userData = userResults[0];

                    // Check if the user is loader banned
                    if (userData.loader_ban === 1) {
                        res.status(403).send('You are loader banned. If you think this is a mistake, please contact Lumiel.');
                        return;
                    }

                    try {
                        // Parse lua_data JSON
                        let luaData = JSON.parse(userData.lua_data);

                        // Find matching Lua script name starting with luaName
                        let matchedLuaScript = luaData.find(script => luaName.startsWith(script.name));

                        // Update or add Lua script entry based on matchedLuaScript
                        if (matchedLuaScript) {
                            const keyExpiry = new Date(keyResults[0].expiry_time); // Convert MySQL date to JavaScript Date object

                            // Ensure UTC date is incremented by 1 day
                            keyExpiry.setUTCDate(keyExpiry.getUTCDate() + 1);

                            // Convert existing time in luaData to Date object and ensure UTC time
                            const currentLuaTime = new Date(matchedLuaScript.time);
                            const currentLuaTimeUTC = new Date(currentLuaTime.getTime() + (currentLuaTime.getTimezoneOffset() * 60000));

                            // Log keyExpiry and currentLuaTime for debugging
                            console.log('Key Expiry (from MySQL):', keyExpiry.toISOString());
                            console.log('Current Lua Time (from luaData):', currentLuaTimeUTC.toISOString());
                            console.log('Current Lua Time (as stored):', matchedLuaScript.time);

                            // Compare UTC timestamps to ensure correct comparison
                            if (keyExpiry.getTime() > currentLuaTimeUTC.getTime()) {
                                // If keyExpiry is greater than currentLuaTimeUTC, update matchedLuaScript.time
                                matchedLuaScript.time = keyExpiry.toISOString();
                                console.log('Updated Lua Script Time:', matchedLuaScript.time);
                            } else {
                                // If keyExpiry is not greater than currentLuaTimeUTC, add another day to matchedLuaScript.time
                                currentLuaTime.setUTCDate(currentLuaTime.getUTCDate() + 1);
                                matchedLuaScript.time = currentLuaTime.toISOString();
                                console.log('Added 1 more day to Lua Script Time:', matchedLuaScript.time);
                            }

                            // Determine current and new build types
                            const currentBuildType = matchedLuaScript.build || 'live';
                            const newBuildType = buildType;

                            // Determine priority levels for build types
                            const buildTypePriority = {
                                'debug': 3,
                                'beta': 2,
                                'live': 1
                            };

                            // Check if the new build type has higher priority
                            if (buildTypePriority[newBuildType] > buildTypePriority[currentBuildType]) {
                                // Update existing Lua script's build type if necessary
                                matchedLuaScript.build = newBuildType;
                            } else {
                                // Keep the current build type, don't downgrade
                                console.log(`Key redeemed for ${luaName} is of lower or equal priority (${newBuildType}) than current build (${currentBuildType}). Keeping current build type.`);
                            }

                        } else {
                            const keyExpiry = new Date(keyResults[0].expiry_time); // Convert MySQL date to JavaScript Date object

                            // Ensure UTC date is incremented by 1 day
                            keyExpiry.setUTCDate(keyExpiry.getUTCDate() + 1);

                            // Log keyExpiry for debugging
                            console.log('Key Expiry (from MySQL):', keyExpiry.toISOString());

                            // Create a new Lua script entry
                            luaData.push({
                                name: luaName,
                                ban: false,
                                time: keyExpiry.toISOString(),
                                build: buildType
                            });
                        }

                        // Update user's lua_data in the database
                        const updateQuery = 'UPDATE users SET lua_data = ? WHERE id = ?';
                        userDataConnection.query(updateQuery, [JSON.stringify(luaData), userData.id], (err, result) => {
                            if (err) {
                                console.error('Error updating lua_data:', err);
                                res.status(500).send('Error updating lua_data');
                            } else {
                                console.log(`Updated lua_data for user ${username}`);

                                // Delete the redeemed key from the database
                                const deleteKeyQuery = 'DELETE FROM `keys` WHERE `key_value` = ?';
                                userDataConnection.query(deleteKeyQuery, [key], (err, deleteResult) => {
                                    if (err) {
                                        console.error('Error deleting key:', err);
                                        res.status(500).send('Error deleting key');
                                    } else {
                                        console.log(`Deleted key ${key} from database`);
                                        res.status(200).send('Key redeemed successfully');
                                    }
                                });
                            }
                        });
                    } catch (error) {
                        console.error('Error parsing lua_data JSON:', error);
                        res.status(500).send('Error parsing lua_data JSON');
                    }
                } else {
                    res.status(404).send('User not found');
                }
            });
        } else {
            res.status(403).send('Invalid or expired key');
        }
    });
});


// Function to extract lua name and build type from key
function extractLuaNameAndBuildType(key) {
    let luaName = '';
    let buildType = determineBuildType(key); // Determine build type based on the key initially

    // Look for beta or debug in the key
    const betaIndex = key.toLowerCase().indexOf('beta');
    const debugIndex = key.toLowerCase().indexOf('debug');

    // Determine where to stop reading based on beta or debug presence
    let endIndex;
    if (betaIndex !== -1 && debugIndex !== -1) {
        endIndex = Math.min(betaIndex, debugIndex);
    } else if (betaIndex !== -1) {
        endIndex = betaIndex;
    } else if (debugIndex !== -1) {
        endIndex = debugIndex;
    } else {
        // If neither beta nor debug is found, remove the {content}
        const braceIndex = key.indexOf('{');
        endIndex = braceIndex !== -1 ? braceIndex : key.length;
    }

    luaName = key.substring(0, endIndex).trim();

    return { luaName, buildType };
}

// Function to determine build type based on key
function determineBuildType(key) {
    if (key.toLowerCase().includes('beta')) {
        return 'beta';
    } else if (key.toLowerCase().includes('debug')) {
        return 'debug';
    } else {
        return 'live';
    }
}

// API endpoint to ban a user by username
app.post('/api/ban/:username', (req, res) => {
    const { username } = req.params;

    // Check if the user exists
    const checkUserQuery = 'SELECT id, loader_ban FROM users WHERE username = ?';
    userDataConnection.query(checkUserQuery, [username], (err, userResults) => {
        if (err) {
            console.error('Error checking user:', err);
            res.status(500).send('Error checking user');
            return;
        }

        if (userResults.length === 0) {
            res.status(404).send('User not found');
            return;
        }

        const userData = userResults[0];

        // Check if user is already banned
        if (userData.loader_ban === 1) {
            res.status(400).send('User already banned on loader');
            return;
        }

        // Update loader_ban to 1 for the specified username
        const updateQuery = 'UPDATE users SET loader_ban = 1 WHERE username = ?';
        userDataConnection.query(updateQuery, [username], (err, result) => {
            if (err) {
                console.error('Error banning user:', err);
                res.status(500).send('Error banning user');
            } else {
                console.log(`User ${username} banned successfully`);
                res.status(200).send(`User ${username} banned successfully`);
            }
        });
    });
});

// API endpoint to retrieve Lua scripts for a user by username
app.post('/api/luas/:username', (req, res) => {
    const { username } = req.params;

    // Query to fetch lua_data for the user
    const query = 'SELECT lua_data FROM users WHERE username = ?';
    userDataConnection.query(query, [username], (err, results) => {
        if (err) {
            console.error('Error fetching lua_data:', err);
            res.status(500).json({ error: 'Error fetching lua_data' });
            return;
        }

        if (results.length === 0) {
            res.status(404).json({ error: 'User not found' });
            return;
        }

        const userData = results[0];
        try {
            const luaData = JSON.parse(userData.lua_data);

            // Prepare output string with formatted Lua script information
            let luaScriptList = luaData.map(script => {
                const formattedTime = formatDate(script.time);
                return `${script.name} (${formattedTime}) (${script.build})`;
            }).join(', ');

            // Construct the response string
            const response = `${luaScriptList}`;

            res.status(200).send(response);
        } catch (error) {
            console.error('Error parsing lua_data JSON:', error);
            res.status(500).json({ error: 'Error parsing lua_data JSON' });
        }
    });
});

// Function to format date/time into a human-readable format
function formatDate(timestamp) {
    const momentTime = moment(timestamp);
    const now = moment();

    // Calculate difference in seconds
    const diffSeconds = momentTime.diff(now, 'seconds');

    // Handle subscription expiration
    if (diffSeconds <= 0) {
        return 'Subscription expired';
    }

    // Calculate days, hours, minutes, seconds
    const days = Math.floor(diffSeconds / (24 * 3600));
    const hours = Math.floor((diffSeconds % (24 * 3600)) / 3600);
    const minutes = Math.floor((diffSeconds % 3600) / 60);
    const seconds = diffSeconds % 60;

    // Construct time string based on remaining time
    let timeString = '';
    if (days > 0) {
        timeString += `${days} day${days > 1 ? 's' : ''} `;
    }
    if (hours > 0) {
        timeString += `${hours} hour${hours > 1 ? 's' : ''} `;
    }
    if (minutes > 0) {
        timeString += `${minutes} minute${minutes > 1 ? 's' : ''} `;
    }
    if (seconds > 0) {
        timeString += `${seconds} second${seconds > 1 ? 's' : ''} `;
    }

    // Trim trailing space and return the formatted time string
    return timeString.trim();
}


// Periodically check and update Lua script validity (if needed)
// Adjust as per your application requirements
setInterval(() => {
    // Example: Fetch all users and update lua_data based on current time
    userDataConnection.query('SELECT id, lua_data FROM users', (err, users) => {
        if (err) {
            console.error('Error fetching users:', err);
            return;
        }

        users.forEach(user => {
            try {
                const luaData = JSON.parse(user.lua_data);
                luaData.forEach(luaScript => {
                    if (luaScript.time) {
                        const currentTime = new Date();
                        const expiryTime = new Date(luaScript.time);

                        // Check if current time is past expiry time
                        if (currentTime >= expiryTime) {
                            luaScript.ban = true; // Mark script as banned/expired
                            // Optionally, update database with the new lua_data
                            const updateQuery = 'UPDATE users SET lua_data = ? WHERE id = ?';
                            userDataConnection.query(updateQuery, [JSON.stringify(luaData), user.id], (err, result) => {
                                if (err) {
                                    console.error('Error updating lua_data:', err);
                                } else {
                                    console.log(`Updated lua_data for user ${user.username}`);
                                }
                            });
                        }
                    }
                });
            } catch (error) {
                console.error('Error parsing lua_data JSON:', error);
            }
        });
    });
}, 3600000); // Check every hour (3600000 ms = 1 hour)

// IP Rate Limiting Logic
const ipAddresses = {}; // Object to store request counts by IP address

const rateLimitMiddleware = (req, res, next) => {
    const ipAddress = req.ip; // Get the IP address of the requester

    // Initialize request count for the IP address if it doesn't exist
    if (!ipAddresses[ipAddress]) {
        ipAddresses[ipAddress] = {
            count: 0,
            lastReset: Date.now()
        };
    }

    const ipData = ipAddresses[ipAddress];
    const windowMs = 15 * 60 * 1000; // 15 minutes
    const maxRequests = 2; // Max requests per IP per window

    // Check if the window has passed since last reset
    if (Date.now() - ipData.lastReset > windowMs) {
        // Reset the count if window has passed
        ipData.count = 0;
        ipData.lastReset = Date.now();
    }

    // Increment request count and check against limit
    ipData.count++;
    if (ipData.count > maxRequests) {
        // Rate limit exceeded
        return res.status(429).send('Too many requests from this IP, please try again after 15 minutes');
    }

    // Continue to the next middleware or route handler
    next();
};

// Apply rate limiting middleware to all requests
app.use(rateLimitMiddleware);

// Register endpoint with IP rate limiting
app.post('/api/register/:username/:hwid', (req, res) => {
    const { username, hwid } = req.params;

    // Check if username already exists
    userDataConnection.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {
        if (err) {
            console.error('Error checking username:', err);
            return res.status(500).send('Failed to register user');
        }

        if (results.length > 0) {
            // Username already taken
            return res.status(400).send('Username already taken. Try another username.');
        }

        // Check if hwid is linked to any account
        userDataConnection.query('SELECT * FROM users WHERE hwid = ?', [hwid], (err, results) => {
            if (err) {
                console.error('Error checking hwid:', err);
                return res.status(500).send('Failed to register user');
            }

            if (results.length > 0) {
                // HWID already linked to an account
                return res.status(400).send('You already have an account linked to your hwid.');
            }

            // Insert new user into database
            const userData = {
                username: username,
                hwid: hwid,
                lua_data: '[]', // Assuming an empty array for Lua data initially
                loader_ban: 0,
                discord_id: null
            };

            userDataConnection.query('INSERT INTO users SET ?', userData, (err, insertResult) => {
                if (err) {
                    console.error('Error inserting user:', err);
                    return res.status(500).send('Failed to register user');
                }

                // Respond with success message
                res.status(201).send(`User '${username}' registered successfully`);
            });
        });
    });
});


app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
