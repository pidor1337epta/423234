elevate2 *it has the version in case the version doesn't match loader will not load
elevate * it doesn't have version i think just check between them
- dont forget to change the port 
- setup ur database
- import the sql database
- loader with name dont use has another hwid system and just get gpu nothing more so use the other one
- if u dont know how to setup ask someone to do or i'll do for u later