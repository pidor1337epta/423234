-- phpMyAdmin SQL Dump
-- version 5.1.1deb5ubuntu1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 12, 2024 at 11:35 AM
-- Server version: 10.6.18-MariaDB-0ubuntu0.22.04.1
-- PHP Version: 8.1.2-1ubuntu2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_data`
--

-- --------------------------------------------------------

--
-- Table structure for table `keys`
--

CREATE TABLE `keys` (
  `id` int(11) NOT NULL,
  `key_value` varchar(100) NOT NULL,
  `expiry_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `keys`
--

INSERT INTO `keys` (`id`, `key_value`, `expiry_time`) VALUES
(43, 'gloriosa{6vhdsykIah6nkogHSevbPdm4DMDapv9jcjTljdW8}', '2024-07-02 23:40:25'),
(46, 'gloriosabeta{nef8iELmaPuLRb9G6F6Bf49JEDp5arSnCVzAHpfz}', '2024-07-02 23:57:35'),
(75, 'gloriosa{6Hr3SZgyBGGPFkvCiSnjwEme1fqwQoTlQsNuI0EE}', '2024-07-12 23:34:25'),
(94, 'Monstrybeta{7i9Y07ctYsIUUlTqGDh3T6c3vMEl7N56kUKYbnPJ}', '2028-08-08 05:31:03'),
(98, 'Monstrybeta{n1FNvfMzwzx4ifdi5wNF4FvKpF35nhRYoH80UXgP}', '2024-10-10 10:24:14');

-- --------------------------------------------------------

--
-- Table structure for table `lua_projects`
--

CREATE TABLE `lua_projects` (
  `id` int(11) NOT NULL,
  `guild_id` varchar(50) DEFAULT NULL,
  `lua_name` varchar(255) DEFAULT NULL,
  `project_path` varchar(255) DEFAULT NULL,
  `key` varchar(50) DEFAULT NULL,
  `key_used` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lua_projects`
--

INSERT INTO `lua_projects` (`id`, `guild_id`, `lua_name`, `project_path`, `key`, `key_used`) VALUES
(22, '1234228597611561002', 'zenith', '/root/projects/lua/lua/zenith', '07fcc87a6f9d34a00fabfd022f46d29c', 1),
(24, '1205694256522600529', 'gloriosa', '/root/projects/lua/lua/gloriosa', 'a99e1e7c1e79ae028acbe09e83882fe0', 1),
(25, '1259772940984258610', 'Monstry', '/root/projects/lua/lua/Monstry', 'faf201384f20355cc5055eab4ab7c696', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `hwid` varchar(255) DEFAULT NULL,
  `lua_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`lua_data`)),
  `loader_ban` tinyint(4) DEFAULT 0,
  `discord_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `hwid`, `lua_data`, `loader_ban`, `discord_id`) VALUES
(22, 'hakkai', 'NDMxODo0NTUwOjIyMTczNDkxODc6TlZJRElBIEdlRm9yY2UgR1RYIDY1MCBUaQ==', '[{\"name\": \"gloriosa\", \"ban\": false, \"time\": \"2024-07-12T18:21:20.000Z\", \"build\": \"beta\"},{\"name\": \"gloriosa\", \"ban\": false, \"time\": \"2024-07-12T18:21:20.000Z\", \"build\": \"beta\"}]', 0, '1041340693890740295'),
(23, 'poseidon', 'NDMxODo5MzUzOjYxMjk2MjUyNjpOVklESUEgR2VGb3JjZSBSVFggMzA2MCBUaQ==', '[{\"name\":\"gloriosa\",\"ban\":false,\"time\":\"2024-07-14T20:05:37.000Z\",\"build\":\"live\"}]', 0, '776364823838851083'),
(24, 'jaks', 'NDMxODo4MDY2Ojg5ODk2MzkzMDpOVklESUEgR2VGb3JjZSBHVFggMTY1MA==', '[{\"name\":\"gloriosa\",\"ban\":false,\"time\":\"2032-09-27T20:10:27.000Z\",\"build\":\"debug\"}]', 0, '1191521351807275019'),
(25, 'alex', 'NDMxODoxMDExNDoxMDkwNTI0MjQ4Ok5WSURJQSBHZUZvcmNlIFJUWCA0MDcwIFRp', '[{\"name\":\"gloriosa\",\"ban\":false,\"time\":\"2024-07-18T20:45:51.000Z\",\"build\":\"debug\"},{\"name\":\"Monstry\",\"ban\":false,\"time\":\"2024-07-15T08:18:36.000Z\",\"build\":\"beta\"}]', 0, '886239464756768808'),
(26, 'draugsxyz', 'NDMxODo5NjAyOjM3MzE2NjMwMjpOVklESUEgR2VGb3JjZSBSVFggMzA1MA==', '[{\"name\":\"gloriosa\",\"ban\":false,\"time\":\"2024-07-19T21:18:15.000Z\",\"build\":\"live\"}]', 0, '959929273446178836'),
(27, 'dreamess', 'NDMxODo3MDQwOjIyNDY1NzgyNDM6TlZJRElBIEdlRm9yY2UgR1RYIDEwODA=', '[{\"name\":\"Monstry\",\"ban\":false,\"time\":\"2028-08-09T01:48:08.000Z\",\"build\":\"beta\"}]', 0, '1062273119852695563'),
(28, 'scarface', 'NDMxODo4NTgwOjIzNzUwOTUzOTQ6TlZJRElBIEdlRm9yY2UgR1RYIDE2NjA=', '[{\"name\":\"Monstry\",\"ban\":false,\"time\":\"2024-07-27T01:49:44.000Z\",\"build\":\"beta\"}]', 0, '546742944300924928'),
(30, 'valentin', 'NDMxODo3OTQ0OjIyNjM4Nzk3NDc6TlZJRElBIEdlRm9yY2UgUlRYIDIwNjA=', '[{\"name\":\"Monstry\",\"ban\":false,\"time\":\"2024-08-12T03:35:19.000Z\",\"build\":\"beta\"}]', 0, '379134042919927808'),
(32, 'kraken', 'NDMxODo5MzQ4OjEwNzg3Mjc3Njg6TlZJRElBIEdlRm9yY2UgUlRYIDMwNzA=', '[{\"name\":\"Monstry\",\"ban\":false,\"time\":\"2024-07-27T06:32:29.000Z\",\"build\":\"beta\"}]', 0, '241448642811133952'),
(33, 'francyzj', 'NDMxODo4MDgxOjI3ODg1OTg0MzpOVklESUEgR2VGb3JjZSBHVFggMTY1MA==', '[{\"name\":\"Monstry\",\"ban\":false,\"time\":\"2024-08-12T07:45:32.000Z\",\"build\":\"beta\"}]', 0, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keys`
--
ALTER TABLE `keys`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lua_projects`
--
ALTER TABLE `lua_projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `key` (`key`),
  ADD UNIQUE KEY `unique_key` (`key`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `keys`
--
ALTER TABLE `keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT for table `lua_projects`
--
ALTER TABLE `lua_projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
